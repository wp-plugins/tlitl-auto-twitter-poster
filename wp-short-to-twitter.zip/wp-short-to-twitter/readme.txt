﻿=== Plugin Name ===
Contributors: mohandez@hotmail.com
Donate link: http://crazy-eng.com/
Tags: twitter, tweet, auto-tweet, simple, SEO, seo, tli.tl ,auto,
Requires at least: 2.7.0
Tested up to: 2.9
Stable tag: 1.5.1

This WP Twitter plugin auto posts updates from your blog to twitter, auto shorten URLs with TLI.TL url shortener 

== Description ==

This Wordpress Twitter plugin posts updates from your blog to your twitter account when you create a fresh post
auto shorten URLs with TLI.TL url shortener 

== Installation ==

Installation

<p style="text-align: center; color: #f00;">* This Plugin Requires CURL *</p>

All you have to do is download, unzip, upload to your plugins folder and activate it from the plugins menu.


== Screenshots ==

1. http://i39.tinypic.com/jpknf6.png
2. http://i43.tinypic.com/243n39j.png

== Changelog ==

= 1.0 =

*Initial stable release

== Frequently Asked Questions ==
Q1. why shorten ?
A1. because twitter Allows 140 letter per post

== Upgrade Notice ==
just visit us for upgrade notices
